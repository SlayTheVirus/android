THIS IS THE 1.15-1.16 VERSION!!

To properly use this pack, place .ogg files in the 'records' folder with one of the following names:

13.ogg
cat.ogg
blocks.ogg
chirp.ogg
far.ogg
mall.ogg
mellohi.ogg
stal.ogg
stard.ogg
ward.ogg
11.ogg
wait.ogg
pigstep.ogg